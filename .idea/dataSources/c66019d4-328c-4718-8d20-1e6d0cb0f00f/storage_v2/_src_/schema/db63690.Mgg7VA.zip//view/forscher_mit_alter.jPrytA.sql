create view forscher_mit_alter as
select `db63690`.`forscher`.`forscher_id`                                               AS `forscher_id`,
       `db63690`.`forscher`.`vorname`                                                   AS `vorname`,
       `db63690`.`forscher`.`nachname`                                                  AS `nachname`,
       `db63690`.`forscher`.`geburtsdatum`                                              AS `geburtsdatum`,
       `db63690`.`forscher`.`berufung`                                                  AS `berufung`,
       `db63690`.`forscher`.`ankunft_rakete_fk`                                         AS `ankunft_rakete_fk`,
       `db63690`.`forscher`.`abflug_rakete_fk`                                          AS `abflug_rakete_fk`,
       floor((to_days(`db63690`.`forscher`.`geburtsdatum`) - to_days(curdate())) / 365) AS `alter`
from `db63690`.`forscher`;

