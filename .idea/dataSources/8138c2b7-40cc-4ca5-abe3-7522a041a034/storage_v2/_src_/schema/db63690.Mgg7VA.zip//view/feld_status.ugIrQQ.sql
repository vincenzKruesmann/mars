create definer = u63690@`%` view feld_status as
select `f`.`feld_id` AS `feld_id`, `f`.`laenge` AS `laenge`, `f`.`breite` AS `breite`, `a`.`anbau_id` AS `anbau_id`
from (`db63690`.`feld` `f`
         left join `db63690`.`anbau` `a` on (`f`.`feld_id` = `a`.`feld_fk` and !exists(select 1
                                                                                       from `db63690`.`ernte`
                                                                                       where `db63690`.`ernte`.`zeitpunkt` > `a`.`zeitpunkt`
                                                                                         and `db63690`.`ernte`.`feld_fk` = `a`.`feld_fk`
                                                                                       limit 1)));

