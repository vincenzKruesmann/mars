create definer = u63690@`%` view essen_art_uebrig as
select `essen_uebrig`.`name` AS `name`, sum(`essen_uebrig`.`uebrig`) AS `sum(uebrig)`
from `db63690`.`essen_uebrig`
group by `essen_uebrig`.`name`;

