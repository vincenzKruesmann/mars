create definer = u63690@`%` view forscher_mit_alter as
select `db63690`.`forscher`.`forscher_id`                                                  AS `forscher_id`,
       `db63690`.`forscher`.`vorname`                                                      AS `vorname`,
       `db63690`.`forscher`.`nachname`                                                     AS `nachname`,
       `db63690`.`forscher`.`geburtsdatum`                                                 AS `geburtsdatum`,
       `db63690`.`forscher`.`berufung`                                                     AS `berufung`,
       `db63690`.`forscher`.`ankunft_rakete_fk`                                            AS `ankunft_rakete_fk`,
       floor((to_days(curdate()) - to_days(`db63690`.`forscher`.`geburtsdatum`)) / 365.25) AS `alter`
from `db63690`.`forscher`;

