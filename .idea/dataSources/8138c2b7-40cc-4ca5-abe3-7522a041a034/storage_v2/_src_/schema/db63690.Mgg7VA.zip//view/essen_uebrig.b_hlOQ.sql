create definer = u63690@`%` view essen_uebrig as
select `db63690`.`essen`.`essen_id`                            AS `essen_id`,
       `db63690`.`essen`.`name`                                AS `name`,
       `db63690`.`essen`.`kalorien`                            AS `kalorien`,
       `db63690`.`essen`.`gewicht`                             AS `gewicht`,
       `db63690`.`essen`.`ernte_fk`                            AS `ernte_fk`,
       `db63690`.`essen`.`rakete_fk`                           AS `rakete_fk`,
       `db63690`.`essen`.`gewicht` - coalesce((select sum(`db63690`.`essen_anbau`.`gewicht`)
                                               from `db63690`.`essen_anbau`
                                               where `db63690`.`essen_anbau`.`essen_fk` = `db63690`.`essen`.`essen_id`),
                                              0) - coalesce((select sum(`db63690`.`essen_forscher`.`gewicht`)
                                                             from `db63690`.`essen_forscher`
                                                             where `db63690`.`essen_forscher`.`essen_fk` = `db63690`.`essen`.`essen_id`),
                                                            0) AS `uebrig`
from `db63690`.`essen`;

